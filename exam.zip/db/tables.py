from classes import Address, City, Country
@staticmethod
def address_tables():
    services = input("""
                1. History
                2. Mening addresim
                0. Back
                    >>> """)

    if services == '1':
        data = Address.select()
        for i in data:
            print(i)
        back = input("""
                    0. Back
                    >>> """)
        if back == '0':
            return address_tables()

    elif services == '2':
        name = input("Name: ")
        city_id = int(input("City Id: "))
        address = Address(name, city_id)
        print(address.insert())
        return city_tables()



    elif services == '0':
        return main()



def city_tables():
    services = input("""
            1. History
            2. Mening shahrim
            0. Back
                >>> """)

    if services == '1':
        City.select()
        back = input("""
                0. Back
                >>> """)
        if back == '0':
            return city_tables()

    elif services == '2':
        name = input("Name: ")
        country_id = int(input("Country Id: "))
        city = City(name, country_id)
        print(city.insert())
        print("Xaridingiz uchun rahmat")

    elif services == '0':
        return main()

