from classes import *
from account import *
from tables import *


def main(username, password):
    tables = input("""
        1. Category Table
        2. Products
        3. Ordering
        4. My account
        >>> """)

    if tables == '1':
        return category_tables()

    elif tables == '2':
        return product_tables()

    elif tables == '3':
        return order_table()

    elif tables == '4':
        return account(username, password)



    else:
        print("Error")
        return main()





def category_tables():
    services = input("""
                    1. Select
                    2. Insert
                    3. Update
                    4. Delete
                    0. Back
                        >>> """)

    if services == '1':
        Category.select()
        # for i in data:
        #     print(i)
        back = input("""
                        0. Back
                        >>> """)
        if back == '0':
            return category_tables()

    elif services == '2':
        name = input("Name: ")
        category = Category(name)
        print(category.insert())
        return category_tables()

    elif services == '3':
        column = input("Column Name: ")
        old_data = input("Old Data: ")
        new_data = input("New Data: ")
        print(Category.update(column, old_data, new_data, "category"))

        return category_tables()

    elif services == '4':
        column = input("Column Name: ")
        data = input("Data: ")
        print(Category.delete(column, data, "category"))
        return category_tables()






def product_tables():
    services = input("""
                1. Select
                2. Insert
                3. Update
                4. Delete
                    >>> """)

    if services == '1':
        data = Product.select()
        for i in data:
            print(i)
        back = input("""
                    0. Back
                    >>> """)
        if back == '0':
            return product_tables()

    elif services == '2':
        name = input("Name: ")
        description = input("Description: ")
        price = input("Price: ")
        count = input("Count: ")
        serial_number = input("Serial Number: ")
        start_date = input("Start Date: ")
        end_date = input("End Date: ")
        category_id = int(input("Category Id: "))
        product = Product(name, description, price, count, serial_number, start_date, end_date, category_id)
        print(product.insert())
        return product_tables()

    elif services == '3':
        column = input("Column Name: ")
        old_data = input("Old Data: ")
        new_data = input("New Data: ")
        print(Product.update(column, old_data, new_data, "product"))

        return product_tables()


    elif services == '4':
        column = input("Column Name: ")
        data = input("Data: ")
        print(Product.delete(column, data, "product"))
        return product_tables()

def order_table():
    services = input("""
             1. Select
             2. Ordering
                >>> """)
    if services == "1":
        data = Orders.select()
        for i in data:
            print(i)
        return order_table()

    elif services == "2":
        id = input("Stoib olmoqchi bo'lgan mahsulotingizning id raqamini kiriting >>> ")
        tanlov = Orders.select()
        for i in tanlov:
            if i[0] == id:
                print("Adressingiz haqida malumotlarni kiriting!")

        return address_tables()
    pass

