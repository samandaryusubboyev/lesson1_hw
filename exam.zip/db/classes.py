from manage import Database



class Country:
    table_name = "country"
    def __init__(self, name):
        self.name = name

    @staticmethod
    def select():
        query = f"SELECT * FROM {Country.table_name} ORDER BY id"
        data = Database.connect(query, "select")
        for i in data:
            print(i)

    def insert(self):
        query = f"""
            INSERT INTO country(name) VALUES ('{self.name}')
        """
        return Database.connect(query, "insert")
    @staticmethod
    def update(column, old_data, new_data, table) -> str:
        if column == 'id':
            query = f"UPDATE {table} SET {column} = {new_data} WHERE {column} = {old_data}"

        else:
            query = f"UPDATE {table} SET {column} = '{new_data}' WHERE {column} = '{old_data}'"

        return Database.connect(query, "update")

    @staticmethod
    def delete(column, data, table):
        if column == "id":
            query = f"DELETE FROM {table} WHERE {column} = {data}"
        else:
            query = f"DELETE FROM {table} WHERE {column} ='{data}'"
        return Database.connect(query, "delete")


class City(Country):
    table_name = "city"

    def __init__(self, name, country_id):
        Country.__init__(self, name)
        self.country_id = country_id

    @staticmethod
    def select():
        query = f"SELECT * FROM {City.table_name} ORDER BY id"
        data = Database.connect(query, "select")
        for i in data:
            print(i)

    def insert(self):
        query = f"""
               INSERT INTO city(name, country_id) VALUES ('{self.name}', {self.country_id})
           """
        return Database.connect(query, "insert")


class Address(Country):
    table_name = "address"

    def __init__(self, name, city_id):
        Country.__init__(self, name)
        self.city_id = city_id

    @staticmethod
    def select():
        query = """
                SELECT a.id, a.name as Address_Name, c.name as City_Name
                FROM address a
                       INNER JOIN city c on a.city_id = c.id
                ORDER BY a.id"""
        return Database.connect(query, "select")

    def insert(self):
        query = f"""
                   INSERT INTO address(name, city_id) VALUES ('{self.name}', {self.city_id})
               """
        return Database.connect(query, "insert")


class Staff(Country):
    table_name = "address"

    def __init__(self, first_name, last_name, address_id):
        Country.__init__(self, name)
        self.first_name = first_name
        self.last_name = last_name
        self.address_id = address_id

    @staticmethod
    def select():
        query = """
                    SELECT s.id, s.first_name as First_name, s.last_name, a.name as Address_Name
                    FROM staff s
                           INNER JOIN address a on s.address_id = a.id
                    ORDER BY s.id"""
        return Database.connect(query, "select")

    def insert(self):
        query = f"""
                       INSERT INTO staff(first_name, last_name, address_id) VALUES ('{self.first_name}', '{self.last_name}', {self.address_id})
                   """
        return Database.connect(query, "insert")


class Customers(Country):
    table_name = "customers"

    def __init__(self, first_name, last_name, username, password):
        self.first_name = first_name
        self.last_name = last_name
        self.username = username
        self.password = password


    @staticmethod
    def select():
        query = f"SELECT * FROM {Customers.table_name} ORDER BY id"
        data = Database.connect(query, "select")
        for i in data:
            print(i)

    def insert(self):
        query = f"""
                   INSERT INTO customers(first_name, last_name, username, password) VALUES ('{self.first_name}', '{self.last_name}', '{self.username}', '{self.password}')
               """
        return Database.connect(query, "insert")
    @staticmethod
    def personal_data(username, password):
        query = f"SELECT * FROM {Customers.table_name} WHERE username = '{username}' and password = '{password}'"
        return Database.connect(query, "select")


class Payment_status:
    pass


class Category(Country):
    table_name = "category"

    def __init__(self, name):
        Country.__init__(self, name)

    @staticmethod
    def select():
        query = f"SELECT * FROM {Category.table_name} ORDER BY id"
        data = Database.connect(query, "select")
        for i in data:
            print(i)

    def insert(self):
        query = f"""
                   INSERT INTO category(name) VALUES ('{self.name}')
               """
        return Database.connect(query, "insert")




class Brand(Country):
    table_name = "brand"

    def __init__(self, name):
        Country.__init__(self, name)
    @staticmethod
    def select():
        query = f"SELECT * FROM {Store.table_name} ORDER BY id"
        data = Database.connect(query, "select")
        for i in data:
            print(i)

    def insert(self):
        query = f"""
                INSERT INTO brand(name) VALUES ('{self.name}')
            """
        return Database.connect(query, "insert")


class Product(Country):
    table_name = "product"

    def __init__(self, name, description, price, count, serial_number, start_date, end_date, brand, category_id):
        Country.__init__(self, name)
        self.description = description
        self.price = price
        self.count = count
        self.serial_number = serial_number
        self.start_date = start_date
        self.end_date = end_date
        self.brand = brand
        self.category_id = category_id

    # @staticmethod
    # def select():
    #     query = f"SELECT * FROM {Store.table_name} ORDER BY id"
    #     data = Database.connect(query, "select")
    #     for i in data:
    #         print(i)

    @staticmethod
    def select():
        query = """
        SELECT p.id, p.name as Product_Name, p.description, p.price, p.count,
               p.start_date, p.end_date, c.name as Category_Name
        FROM product p
               INNER JOIN category c on p.category_id = c.id
        ORDER BY p.id"""
        return Database.connect(query, "select")

    def insert(self):
        query = f"""
                       INSERT INTO product(name, description, price, count, serial_number, start_date, end_date, category_id) 
                       VALUES ('{self.name}', '{self.description}', {self.price}, {self.count}, {self.serial_number}, '{self.start_date}', '{self.end_date}', {self.category_id})
                   """
        return Database.connect(query, "insert")


class Orders(Product):
    table_name = "order"


    @staticmethod
    def select():
        query = """
            SELECT p.id, p.name as Product_Name, p.description, p.price, p.count,
                   p.start_date, p.end_date, c.name as Category_Name
            FROM product p
                   INNER JOIN category c on p.category_id = c.id
            ORDER BY p.id"""
        return Database.connect(query, "select")




