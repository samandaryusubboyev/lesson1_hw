from classes import Country, City, Customers
from manage import Check
from admin import main





def login():
    username = input("Username: ")
    password = input("Password: ")
    if Check.login_check(username, password):
        return main(username, password)

    else:
        print("Username yoki Password noto'g'ri!")
        return login()
def register():
    print("Register Page")
    first_name = input("First Name: ")
    last_name = input("Last Name: ")
    username = input("Username: ")
    password_1 = input("Password: ")
    password_2 = input("Reply Password: ")
    while password_1 != password_2:
        print("Passwordlar mos kelmadi!")
        password_1 = input("Password: ")
        password_2 = input("Reply Password: ")

    new_customer = Customers(first_name, last_name, username, password_1)
    print(new_customer.insert())

    return login()



def intro():
    user = input("""
        1. Login>>>
        2. Register>>>
        >>> """)

    if user =="1":
        return login()


    elif user == "2":
        return register()

    else:
        print("Error!")
        return intro()


if __name__ == "__main__":
    intro()

